import java.util.*;
import java.lang.*;
import java.io.*;
import java.util.LinkedList;

class FordFulkerson {

    static final int V = 6; // number of nodes

    static LinkedList<Integer> cut = new LinkedList<>(); // create linkedlist

    boolean bfs(int residualGraph[][], int s, int t, int parent[]) { //
        boolean visited[] = new boolean[V];
        for (int i = 0; i < V; ++i) {
            visited[i] = false;
        }
        LinkedList<Integer> queue = new LinkedList<Integer>(); // LinkedList for nodes stocking
        queue.add(s);
        visited[s] = true;
        parent[s] = -1;

        while (queue.size() != 0) {
            int u = queue.poll();

            for (int v = 0; v < V; v++) {
                if (visited[v] == false && residualGraph[u][v] > 0) {
                    queue.add(v);
                    parent[v] = u;
                    visited[v] = true;
                }
            }
        }

        return (visited[t] == true);
    }

    int FordFulkerson(int graph[][], int s, int t) {
        int u, v;
        int residualGraph[][] = new int[V][V];

        for (u = 0; u < V; u++) {
            for (v = 0; v < V; v++) {
                residualGraph[u][v] = graph[u][v];
            }
        }
        int parent[] = new int[V];

        //Each bath stores the highest value it can hold
        int max_flow = 0;
        while (bfs(residualGraph, s, t, parent)) {
            int path_flow = Integer.MAX_VALUE;
            int min = Integer.MAX_VALUE;
            LinkedList<Integer> path = new LinkedList<>(); // LinkedList For path

            path.add(t);
            int a = Integer.MAX_VALUE;
            int b = Integer.MAX_VALUE;
            int c = Integer.MAX_VALUE;
            for (v = t; v != s; v = parent[v]) {
                u = parent[v];
                path.add(u);
                if (residualGraph[u][v] < min) {
                    min = residualGraph[u][v];
                    a = u;
                    b = v;
                    c = residualGraph[u][v];
                }

                path_flow = Math.min(path_flow, residualGraph[u][v]);
            }

            cut.add(a);
            cut.add(b);
            cut.add(c);
            Iterator<Integer> itr = path.descendingIterator();
            System.out.println("The augment path of the Residual Graph is:");// display augmenting path 
     
            String path1 = itr.next().toString(1);
            System.out.print(path1);
            while (itr.hasNext()) {
                String path2 = itr.next().toString();
                int path2Int = Integer.parseInt(path2) + 1;
                System.out.print("--->" + path2Int);
            }

            System.out.println();
            System.out.print("The augment flow is : " + path_flow);//display value of flow for every path
            System.out.println();
             System.out.println();
            for (v = t; v != s; v = parent[v]) {
                u = parent[v];
                residualGraph[u][v] -= path_flow;// minus flow if the edge backward
                residualGraph[v][u] += path_flow; //sum flow if the edge forward
            }
            max_flow += path_flow;
        }
        return max_flow;
    }

    public static void main(String[] args) throws FileNotFoundException {
        Scanner inputfile = new Scanner(new File("input.txt")); // create input file has all values implemented in ford fulkerson algorithm
        
      
       
        int[][] graph = new int[6][6]; // 2D array graph , 6 = Number of nodes
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                graph[i][j] = 0;
            }
        }

        for (int i = 0; i < 8; i++) { //number of lines in text file
            int source = inputfile.nextInt(); 
            int destination = inputfile.nextInt();
            int length = inputfile.nextInt(); // represent capacity
            graph[source][destination] = length; 
        }

        FordFulkerson m = new FordFulkerson();
        
        System.out.println("\nThe Maximum possible Flow is: " + m.FordFulkerson(graph, 0, 5));//Display Maximum flow in end final iteration 

        System.out.println();
        System.out.println("\nMINIMUM CUT:");
        System.out.println("The Minimum Cut Edges are :");//Display minimum cut for edges 
        Iterator<Integer> itrcut = cut.iterator();
        int cutsum = 0;
        while (itrcut.hasNext()) {

            String track = itrcut.next().toString();
            int trackToInt = Integer.parseInt(track) + 1;
            System.out.print(trackToInt + "-----");
            String track2 = itrcut.next().toString();
            int track2ToInt = Integer.parseInt(track2) + 1;
            System.out.println(track2ToInt);

            cutsum = cutsum + itrcut.next();
        }

    }
}